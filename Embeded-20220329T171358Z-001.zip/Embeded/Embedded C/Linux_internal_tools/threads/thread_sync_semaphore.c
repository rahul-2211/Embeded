//thread_synchronization_semaphore lock
#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>


int shareVar=5;

sem_t my_sem;


void thread_inc(void *arg)
{
    sem_wait(&my_sem);
    shareVar++;
    // printf("after incr=%d\n",shareVar);
    sem_post(&my_sem);
    
}
void thread_dec(void *arg)
{
     sem_wait(&my_sem);
    shareVar--;
    // printf("after incr=%d\n",shareVar);
    sem_post(&my_sem);
}


int main()
{
	pthread_t t1,t2;
// void *res;
// int s;
sem_init(&my_sem,0,1);
pthread_create(&t1,NULL,thread_inc,"Hello world");
pthread_create(&t2,NULL,thread_dec,"Hello world");
// printf("message from  main\n");
// sleep(3);
pthread_join(t1,NULL);
pthread_join(t2,NULL);
// printf("thread retuned %ld\n",(long)res);
printf("shareVar=%d\n",shareVar);
return 0;
}
