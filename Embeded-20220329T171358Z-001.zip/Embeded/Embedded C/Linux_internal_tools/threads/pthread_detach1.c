#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>
#define NUM_THREAD 3

int i = 0;
void *
myfun (void *null)
{
  i++;
  int result = 0;
  printf ("result: %d\n", result);
  pthread_exit (NULL);
}

int
main ()
{
  pthread_t thread[NUM_THREAD];
  pthread_attr_t attr;
  int rc, t, status, detach_state;

  pthread_attr_init (&attr);
  pthread_attr_setdetachstate (&attr, PTHREAD_CREATE_DETACHED);

  for (t = 0; t < NUM_THREAD; t++)
    {
      printf ("creatting thread %d\n", t);
      pthread_create (&thread[t], &attr, myfun, NULL);

    }
  pthread_attr_getdetachstate (&attr, &detach_state);
  printf ("\n detach state: %d\n", (int *) detach_state);
  printf ("\n exiting from main thread\n");

  pthread_exit (NULL);


}

