#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>

 
int shareVar = 5;

 
// sem_t my_sem;

 
pthread_mutex_t my_mutex;
 
void *thread_inc (void *arg) 
{
printf("Increment start\n-----------------------------\n");
pthread_mutex_lock(&my_mutex);
printf("first mutex lock\n");  
  
shareVar++;
printf("shareVare: %d\n",shareVar);  
    // printf("after incr=%d\n",shareVar);
pthread_mutex_unlock(&my_mutex);
printf("first mutex unlocked\n");
    // sem_post (&my_sem);

 
} 
void *thread_dec (void *arg) 
{
  printf("decrement start\n-------------------------\n");

pthread_mutex_lock(&my_mutex);
printf("second mutex locked\n");
// sem_wait (&my_sem);

shareVar--;
printf("shareVare: %d\n",shareVar);
    // printf("after incr=%d\n",shareVar);
pthread_mutex_unlock(&my_mutex);
printf("second mutex unlocked\n\n");
    // sem_post (&my_sem);

} 
 
int main () 
{
  
pthread_t t1, t2; 
// void *res;
// int s;
pthread_mutex_init (&my_mutex, NULL);
  
pthread_create (&t1, NULL, thread_inc, NULL);
  
pthread_create (&t2, NULL, thread_dec, NULL);
  
// printf("message from  main\n");
// sleep(3);
pthread_join (t1, NULL);
  
pthread_join (t2, NULL);
  
// printf("thread retuned %ld\n",(long)res);
printf ("shareVar=%d\n", shareVar);
  
return 0;

}

