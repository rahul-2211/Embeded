
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
#include<errno.h>

#include<bits/types.h>
#include<sys/types.h>

static pthread_spinloc_t spinlock;
volatile int slock;//C's volatile keyword is a qualifier that is applied to a variable when it is declared. It tells the compiler that the value of the variable may change at any time--without any action being taken by the code the compiler finds nearby.

void *spinlockThread(void *i)

{
    int rc;
    int count=0;
    printf("entered thread %d gettig spin lock\n",(int*)i);
    rc=pthread_spin_lock(&slock);
    printf("%d thread complete\n",(int*)i);
    return NULL;
}
int main()
{

    int rc=0;
    pthread_t thread,thread1;
    
    if(pthread_spin_init(&slock,PTHREAD_PROCESS_PRIVATE)!=0)
    {
        perror("init");
        printf("main get spinlock\n",(int*)1);
        rc=pthread_spin_lock(&slock);
        
        printf("main creat the spin lock thread\n");
        rc=pthread_create(&thread,NULL,spinlockThread,(int *)1);
        
        printf("main wait a bit holding spin lock\n");
        sleep(5);
        
        printf("\n main thread sucessfully unlocked");
        printf("\n main thread sucessfully unlocked");
        
        printf("\n main wait for the thread to end");
        
        rc=pthread_join(thread,NULL);
        printf("main complete\n");
        return 0;
        
    }
}

