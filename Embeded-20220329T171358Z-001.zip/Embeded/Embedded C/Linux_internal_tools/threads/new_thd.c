#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
#include<errno.h>

#include<bits/types.h>
#include<sys/types.h>

void *process(void *arg)
{
	// pthread_detach(pthread_self());
    printf("sleeping 2 sec\n");
    sleep(2);
    printf("sleeping 2 sec\n");
    
}

int main()
{
pthread_t t_id;
int errono=pthread_create(&t_id,NULL,process,NULL);
if(errono)perror("pthread_create:");
pthread_exit(NULL);
}
