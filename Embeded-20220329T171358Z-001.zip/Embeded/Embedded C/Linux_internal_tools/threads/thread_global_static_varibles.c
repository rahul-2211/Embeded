#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>

int shareVar=5;

void thread_inc(void *arg)
{
    shareVar++;
    printf("after incr=%d\n",shareVar);
}
void thread_dec(void *arg)
{
    shareVar--;
    printf("after decr=%d\n",shareVar);
}


int main()
{
	pthread_t t1,t2;
// void *res;
// int s;
pthread_create(&t1,NULL,thread_inc,"Hello world");
pthread_create(&t2,NULL,thread_dec,"Hello world");
// printf("message from  main\n");
// sleep(3);
pthread_join(t1,NULL);
pthread_join(t2,NULL);
// printf("thread retuned %ld\n",(long)res);
printf("shareVar=%d\n",shareVar);
return 0;
}
