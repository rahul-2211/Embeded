#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{

	printf("can you see me[ONE]\n");
	execl("/home/rahul/Desktop/Embedded C/Linux_internal_tools/exec_codes/exectest_cmd_line","./exec_cmd","kernel","programming");
	printf("can you see me[TWO]\n");

}
