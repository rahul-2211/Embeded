#include<stdio.h>
#include<stdlib.h>

void buggy()
{
	int *intptr;
int i;
intptr=(int*)malloc(sizeof(int)*5);
printf("malloc chrcking : Addre=%08x and size=%d\n",intptr,sizeof(int)*5);

for(int i=0;i<4;i++)
{
	*intptr =100;
printf("value of intptr =%d\n",(*intptr));
intptr++;

}
}
int main()
{
buggy();
return 0;
}
