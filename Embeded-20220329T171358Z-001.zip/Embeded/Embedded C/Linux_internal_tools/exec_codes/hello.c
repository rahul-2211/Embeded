#include<stdio.h>

int main()
{
printf("hii rahul\n");
}
