//4. Write a program where pthread task displays the thread id and prints the calling process pid.

#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>

void funt(void *ptr)
{
	printf("hi rahul solanki\n");
	return 0;
}

int main(void)
{
	
	pid_t pid;
	pthread_t tid, tid2;
	pthread_create(&tid,NULL,funt,NULL);
	//pthread_create(&tid2,NULL,funt,NULL);
	sleep(1);
	//wait(NULL);
	//tid=pthread_self();// The pthread_self() function returns the ID of the calling thread.
	//pid=getpid();
	printf("pid is: %u\ntid: %u \n",getpid(),pthread_self());
	//pthread_join(&tid,NULL);
	//pthread_join(&tid2,NULL);
	return 0;
	
}
