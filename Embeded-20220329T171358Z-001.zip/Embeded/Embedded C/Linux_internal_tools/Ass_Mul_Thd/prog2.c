//2.Write a program where thread cancel itself.(use pthread_cancel())

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* call(void* ptr)
{
	int i;
	i=pthread_cancel(pthread_self());//cancel itself thread id
	printf("thread is sucessfully cancelled: %d\n",i);//return 0
}


//main body
int main()
{
	pthread_t thread;
	pthread_create(&thread, NULL, call, NULL);
	pthread_join(thread, NULL);
	//The pthread_join() function provides a simple mechanism allowing an application to wait for a thread to terminate. After the thread 		terminates, the application may then choose to clean up resources that were used by the thread.
	return 0;
}//end of main
