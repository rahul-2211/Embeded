//1.Write a multithreading program, where threads runs same shared golbal variable of the process between them.
#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>

int a=10,b=5,c;//golbal variable

void add(void *arg)//fun1
{
	c=a+b;
	printf("after addition=%d\n",c);
}

void sub(void *arg)//fun2
{
	c=a-b;
	printf("after substraction=%d\n",c);
}

//main body
int main()
{
	pthread_t t1,t2;
	pthread_create(&t1,NULL,add,NULL);
	pthread_create(&t2,NULL,sub,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("c=%d\n",c);
	return 0;
}//end of main
