//3. Write a program that changes the default properties of newly created posix threads. (Ex: to change default pthread stack size)

#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/mman.h>

void* Proc(void * param)
{
    sleep(2);
    return 0;
}



int main()
{
	pthread_attr_t Attr;
	//The attr argument points to a pthread_attr_t structure whose contents are used at thread creation time to determine attributes for the new thread; this structure is initialized using pthread_attr_init(3) and related functions. If attr is NULL, then the 		thread is created with default attributes
	pthread_t Id;
	void *Stk;
	size_t siz;
	//The datatype size_t is unsigned integral type. It represents the size of any object in bytes and returned by sizeof operator.
	int err;
	
	size_t my_stksize=0x30000000;
	void * my_stack;
	
	pthread_attr_init(&Attr);
	pthread_attr_getstacksize(&Attr,&siz);
	pthread_attr_getstackaddr(&Attr,&Stk);
	
	printf("default: Addr=%08x default Size=%d\n",Stk,siz);
	
	my_stack=(void *)malloc(my_stksize);
	
	//Upon successful completion, pthread_attr_getstacksize() and pthread_attr_setstacksize() shall return a value of 0; otherwise, an error number shall be returned to indicate the error.
	//get and set the thread creation stacksize attribute in the attr object.	
	pthread_attr_setstack(&Attr,my_stack,my_stksize);
	
	pthread_attr_create(&Id,Proc,NULL);
	
	pthread_attr_getstack(&Attr,&Stk,&siz);
	
	printf("newly created stack: Addr=%08x ans Size=%d\n",Stk,siz);
	
	sleep(3);
	
	return(0);
	
	
}
