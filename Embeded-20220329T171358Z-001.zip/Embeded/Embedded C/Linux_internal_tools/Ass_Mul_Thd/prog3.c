//3. Write a program that changes the default properties of newly created posix threads. (Ex: to change default pthread stack size)
#include<sys/mman.h>
#include<unistd.h>
#include<pthread.h>
void * proc(void* param)
{
return 0;
}
int main()
{
	pthread_attr_t Attr;
	//The attr argument points to a pthread_attr_t structure whose contents are used at thread creation time to determine attributes for the new thread; this structure is initialized using pthread_attr_init(3) and related 		functions. If attr is NULL, then the thread is created with default attributes
	
	pthread_t ID;
	void *stack;
	size_t siz;
	//The datatype size_t is unsigned integral type. It represents the size of any object in bytes and returned by sizeof operator.
	int error;
	size_t my_stacksize = 0x300000;
	void * my_stack;
	pthread_attr_init(&Attr);//initialise and destroy threads attribute object.
	pthread_attr_getstacksize(&Attr, &siz);
	pthread_attr_getstackaddr(&Attr, &stack);
	//The pthread_attr_getstacksize() and pthread_attr_setstacksize() functions, respectively,shall get and set the thread creation stacksize attribute in the attr object.
	printf("defalut: addr=%x default size=%d\n",stack, siz);
	my_stack = (void*)malloc(my_stacksize);
	pthread_attr_setstack(&Attr, my_stack, my_stacksize);
	// The pthread_attr_setstack() function sets the stackaddr and stacksize attributes in attr from the values of addr and size respectively.
	pthread_create(&ID, &Attr, proc, NULL);
	pthread_attr_getstack(&Attr, &stack,&siz);
	//The pthread_attr_getstack() function gets both the base (lowest addressable) storage address and size of the initial stack segment from a thread attribute structure and stores them into addr and size respectively.
	printf("defalut: addrress=%x default size=%d\n",stack, siz);
	return 0;
}
