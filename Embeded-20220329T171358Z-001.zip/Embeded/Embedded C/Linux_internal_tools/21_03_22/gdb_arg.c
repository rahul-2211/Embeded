#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
int i;
printf("\n file name: %s\n",argv[0]);//a.out
printf("\n total number of aeguments:%d",argc);
printf("\n argument passed:");
for(i=0;i<argc;i++)
         printf("%s",argv[i]);
printf("\n");
}
    
