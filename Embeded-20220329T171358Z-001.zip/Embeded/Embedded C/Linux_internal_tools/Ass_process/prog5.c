#include <stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

int main()
{
    int fd,pid;
    pid=fork();
   if(pid==0)
   {
    // char buff[];
    char buff[]="rahul solanki";
    int len=strlen(buff);
    char buff1[len];
    fd=open("prog5.txt",O_CREAT|O_RDWR,0777);
    write(fd,buff,len);
    read(fd,buff1,len);
   }
   else
   {
       wait(NULL);
       printf("you are inside parent process \n");
   }
    return 0;
}

