//6. Write a program child executes(exec()) a new program , while parent waits for 
//child task to get complete.
#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>


int main()
{
	int pid_1;
	printf("curr process pid=%d\n",getpid());
	printf("\n----------------------------------------------------\n");
	pid_1=fork();
if(pid_1==0) //child
{
	printf("\n----------------------------------------------------\n");	
	printf("new child pid_1 =%d\n",getpid());
	printf("new child parent pid_1 =%d\n",getppid());
	printf("\n----------------------------------------------------\n");	
	execl("/bin/ls","ls",NULL);


}


else
{
	sleep(3);
	wait(NULL);
	printf("\nchild complete\n");
	exit(0);
}
}





