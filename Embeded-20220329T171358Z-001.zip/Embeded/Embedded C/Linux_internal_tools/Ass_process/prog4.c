// 4.A processs using execl() system call should replace a new command line program.
#include<stdio.h>
#include<unistd.h>
int main()
{
execl("/home/rahul/Desktop/Embedded C/Linux_internal_tools/exec_codes/hello","./hello",0);
printf("error return by execl");
return 0;
}
