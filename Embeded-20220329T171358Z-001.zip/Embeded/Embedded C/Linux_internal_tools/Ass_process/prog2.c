//.Write a program such that parent process create two child processes,such that 
//each child executes a separate task.
#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<unistd.h>


int main()
{
	int pid_1,pid_2;
	printf("curr process pid=%d\n",getpid());
	printf("\n----------------------------------------------------\n");
	pid_1=fork();
	pid_2=fork();
if(pid_1==0) //child
{
	printf("\n----------------------------------------------------\n");	
	printf("new child pid_1 =%d\n",getpid());
	printf("new child parent pid_1 =%d\n",getppid());
	printf("\n----------------------------------------------------\n");	
	execl("/bin/ls","ls",NULL);


}

else if(pid_2==0)
{
	printf("new child pid_2 =%d\n",getpid());
	printf("new child parent pid_2 =%d\n",getppid());
	printf("\n----------------------------------------------------\n");
	execl("/home/rahul/Desktop/Embedded C/Linux_internal_tools/exec_codes/hello","./hello",0);
}
else
{
	sleep(3);
	wait(NULL);

	printf("\nchild complete\n");
	exit(0);
}
}

