//3. A program that replaces old program with new program data and is expected to display 
//the currently running processes in a hierarchical tree format.
#include<stdio.h>
#include<unistd.h>

int main()
{
int res=execl("/usr/bin/pstree","/pstree",0);
if(res==-1)
	printf("error return by execl ");
return 0;

}
