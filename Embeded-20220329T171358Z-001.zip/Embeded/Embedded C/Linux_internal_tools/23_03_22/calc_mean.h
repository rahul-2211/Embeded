double mean(double v1,double v2);
double sub(double v1,double v2);


