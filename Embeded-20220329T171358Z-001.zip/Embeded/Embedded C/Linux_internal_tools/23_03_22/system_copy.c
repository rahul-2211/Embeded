#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	int i;
	char buff_comm[5];
	strcpy(buff_comm,"ls -l");
	printf("sys() lib. fun. uses fork() to create a child process\n");
	printf("child process execute execl() which loads and run new program provided by system() argument\n");
	i=system(buff_comm);
	printf("%d",i);	
	return 0;
}
