//memcopy
#include <stdio.h>
#include<string.h>

void memcopy (char *src, char *dest, int count)
{
  int i;
  for (i = 0; i < count; i++)
    {
         *dest = *src;
          dest++;
          src++;
    }
}


main ()
{
  char dest[10] = "oldstring";
  char src[10] = "";



  printf ("before memcopy dest=%s ,src=%s\n", dest, src);
  memcopy (dest, src, 10);
  printf ("after memcopy dest=%s ,src=%s\n", dest, src);


  return 0;


}

