#include<stdio.h>
int main()
{
	int a=1,b=2;
	printf("a is : %d b is : %d ",a,b);
	printf("\nAddition of a and b is : %d",a+b);	
	return 0;
}
