#include<stdio.h>

int push(int a[],int *t,int e,int n)
{
	if(*t<n)
	{
		*t=*t+1;
		a[*t]=e;
		printf("\ntop is: %d",*t);
		return 1;
	}
	else
	{
		printf("\nstack is overflow:");
		return 0;
	}

}

int pop()
{



}
int main()
{
int n=3,s[n],x,top=0;
while(1)
	{
	printf("\nenter element: ");
	scanf("%d",&x);
	if(push(s,&top,x,n)==0)
	{
	break;
	}
	else
	{
	printf("\nelement is pushed");
	}

	}


}

