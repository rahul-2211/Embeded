#include<stdio.h>
int push();
int isfull();
int top=0,s[2],x,n=3;
int main()
{
while(1)
{
	printf("enter element:");
	scanf("%d",&x);
	//push();
	if(push()==0)
	{
	break;
	}

}

}
int isfull()
{

	if (top<=n)
	{
	return 1;
	}
	else
	{
	return 0;
	}

}
int push()
{
	if(isfull())
	{
	printf("stack overflow:");
	return 0;
	}
	else
	{
	top=top+1;
	s[top]=x;
	//printf("element pushed");
	}

}
