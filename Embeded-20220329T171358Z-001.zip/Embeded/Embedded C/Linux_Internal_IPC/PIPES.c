#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>

main()
{
    int fds[2];
    int res,i;
    char *buf1="rahul";
    char *buf="solanki";
    char buf2[40];
    res =pipe(fds);
    
    if(res==-1)
    {
        perror("pipe");
        exit(1);
    }
    write(fds[1],buf1,20);
    write(fds[1],buf,20);
    read(fds[0],buf2,40);
    
    for(i=0;i<40;i++)
        printf("%c",buf2[i]);
    printf("\n");
    
}
/*pipe() is a Linux system function. The pipe() system function is used to open file descriptors, which are used to communicate between different Linux processes. In short, the pipe() function is used for inter-process communication in Linux.  In this article, I am going to show you how to use the pipe() system function in Linux. So, let’s get started.
All About pipe() Function:
The syntax of the pipe() function is:

int pipe(int pipefd[2]);
Here, the pipe() function creates a unidirectional data channel for inter-process communication. You pass in an int (Integer) type array pipefd consisting of 2 array element to the function pipe(). Then the pipe() function creates two file descriptors in the pipefd array.

*/
