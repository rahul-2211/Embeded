#include<stdio.h>
#include<string.h>
int main()
{
char ch[4];
printf("\nenter expression:");
scnafs",ch);
int coef;
printf("\nenter coeffient:");
scnaf("%d",&coef);
for(int i=0;i<4;i++)
{
if(isdigit(i))
	
else

}



}
