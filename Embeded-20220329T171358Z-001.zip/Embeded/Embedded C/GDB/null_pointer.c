#include <stdio.h>

int main()
{
    int *i;
    float *f;
    char *c;
    
    i=NULL;
    f=NULL;
    c=NULL;
    
    printf("value at i is: %d",i);

    return 0;
}

