#include <stdio.h>
#include <string.h>

int main()
{
    int x=1234;
    int arr[5]={11,22,33,44,55};
    char buf[]="kernel";
    
    printf("buff data : %s\n",buf);

    return 0;
}

