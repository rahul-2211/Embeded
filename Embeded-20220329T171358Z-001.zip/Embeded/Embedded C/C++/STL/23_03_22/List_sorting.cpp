//List:sorting

#include<iostream>
#include<list>

using namespace std;

int main()
{
    list<int> lst1;
    list<int> lst2;
    int i;
    for(i=0;i<10;i+=2)
        lst1.push_back(rand()%20);
    for(i=0;i<10;i+=2)
        lst2.push_back(rand()%20);
      
    cout<<"content of list1: "<<endl;
    list<int>:: iterator p = lst1.begin();
      while(p!=lst1.end())
     {   
        cout<<*p<<" ";
        p++;
         
     }
    cout<<"\ncontent of list2: "<<endl;
    list<int>:: iterator p1 = lst2.begin();
       while(p1!=lst2.end())
     {   
        cout<<*p1<<" ";
        p1++;
         
     }
    cout<<"\n\n";
    cout<<"sorted list1"<<endl;
  //  lst1.sort();
    p=lst1.begin();
    
     while(p!=lst1.end())
        {
        cout<<*p<<" ";
        p++;
            
        }
      
    cout<<"\n\n";
    cout<<"sorted list2"<<endl;
   lst2.sort();
    p1=lst2.begin();
    
     while(p1!=lst2.end())
        {
        cout<<*p1<<" ";
        p1++;
            
        }
    cout<<"\nreverse sorted list2"<<endl;
    lst2.reverse();
    p1=lst2.begin();
    
     while(p1!=lst2.end())
        {
        cout<<*p1<<" ";
        p1++;
            
        }
     lst1.merge(lst2);
     p1=lst1.begin();
     if(lst2.empty())
     {
         cout<<"\nlst2 is now empty\n";
         cout<<"content of list after merge:\n"<<endl;
          p1=lst1.begin();
     }
     while(p1!=lst1.end())
        {
        cout<<*p1<<" ";
        p1++;
            
        }
     
     
    return 0;
}
