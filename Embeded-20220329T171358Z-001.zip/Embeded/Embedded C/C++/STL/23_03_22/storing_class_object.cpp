#include<iostream>
#include<map>
#include<string.h>
using namespace std;
class name{
char str[40];
public:
name()
{
strcpy(str," ");
}
name(char *s)
{
strcpy(str,s);
}
char *get()
{
return str;
}
};
bool operator<(name a,name b)
{
return strcmp(a.get(),b.get())<0;
}
class phonenum{
char str[80];
public:
phonenum()
{
strcpy(str," ");
}
phonenum(char *s)
{
strcpy(str,s);
}
char *get()
{
return str;
}
};
int main()
{
map<name,phonenum>dire;
dire.insert(pair<name,phonenum>(name("Emp1"),phonenum("555-1111")));
dire.insert(pair<name,phonenum>(name("Emp2"),phonenum("555-2222")));
dire.insert(pair<name,phonenum>(name("Emp3"),phonenum("555-3333")));
dire.insert(pair<name,phonenum>(name("Emp4"),phonenum("555-4444")));
char str[80];
cout<<"enter name"<<endl;
cin>>str;
map<name,phonenum>::iterator p;
p=dire.find(name(str));
if(p!=dire.end())
{
cout<<"phone number:"<<p->second.get();
}
else
{
cout<<"name is not found in dire"<<endl;
}
return 0;
}

/*
#include<iostream>
#include<string.h>
#include<map>
using namespace std;

class name
{
  char str[20];
  public:
    name()
    {
        strcpy(str,"");
    }
    char* get()
    { return str;}
    
};
bool operator<(name a, name b)
{
    return strcmp(a.get(),b.get())<0;
}

class phoneNum
{
    char str[80];
    public:
    phoneNum()
    {
        strcpy(str,"");
    }
    phoneNum(char *s)
    {
        strcpy(str,s);
    }
    char* get()
    { return str;}
    
};

int main()
{
    map<name , phoneNum> directory;
    directory.insert(pair<name, phoneNum>(name("Emp1"),phoneNum("555-11111")));
    directory.insert(pair<name,phoneNum>(name("Emp2"),phoneNum("555-22222")));
    directory.insert(pair<name,phoneNum>(name("Emp3"),phoneNum("555-33333")));
    directory.insert(pair<name,phoneNum>(name("Emp4"),phoneNum("555-44444")));
    
    char str[80];
    cout<<"enter name:";
    cin>>str;
    map<name,phoneNum>:: iterator p;
    p=directory.find(name(str));
    if(p!=directory.end())
    {
        cout<<"phone-Num"<<p->second.get();
    }
    else
    {
        cout<<"name not in directory";
    }
    return 0;
}




*/
