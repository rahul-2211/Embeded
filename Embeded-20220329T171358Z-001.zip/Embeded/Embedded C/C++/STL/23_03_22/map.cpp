#include<map>
#include<iostream>
using namespace std;
int main()
{
    map<char,int> m;
    int i;
    for(int i=0;i<26;i++)
    {
        m.insert(pair<char,int>('A'+i,65+i));
    }
    char ch;
    cout<<"Enter key (an Upercase letter):";
    cin>>ch;
    map<char,int>::iterator p;
    
    p=m.find(ch);
    if(p!=m.end())
        cout<<"is ASCII value is "<<p->second<<endl;
    else
        cout<<"key is not in map"<<endl;
    
}

