#include<algorithm>
#include<vector>
#include<iostream>
using namespace std;
int main()
{
    char str[]="I Love C++ programing";
    vector<char> v, v2(30);
    int i;
    for(i=0;str[i];i++)
    {
        v.push_back(str[i]);
    }
    cout<<"Input sequence:"<<endl;

     for(i=0;i<v.size();i++)
    {
            cout<<v[i];
    }
    cout<<endl;
    
    remove_copy(v.begin(),v.end(),v2.begin(),' ');
//replace_copy(v.begin(),v.end(),v2.begin(),' ',':');
    
    cout<<"after removing spaces:"<<endl;
    
     for(i=0;i<v.size();i++)
    {
            cout<<v2[i];
    }
    cout<<endl<<endl;
    return 0;
}
