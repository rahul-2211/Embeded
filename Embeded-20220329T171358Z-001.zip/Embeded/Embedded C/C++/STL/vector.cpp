/******************************************************************************

                             Abstraction:hidfe template
                             Encapsularion:security
                             Plymorphism: overloading
                             Inheritance:accesibility and security
*******************************************************************************/

#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector<int> v(10);
    int i;
    cout<<"size: "<<v.size()<<endl;
    
    for(i=0;i<10;i++)
    {
        v[i]=i+'a';
    }
    cout<<"current content"<<endl;
    for(i=0;i<v.size();i++)
    {
        cout<<v[i]<<" ";
    }
    cout<<"\n\n";

    cout<<"expanding content"<<endl;

    for(i=0;i<10;i++)
    {
        v.push_back(i+10+'a');
    }
    cout<<"size now: "<<v.size()<<endl;
    
    cout<<"current content:"<<endl;
    
     for(i=0;i<v.size();i++)
    {
        cout<<v[i]<<" ";
    }
     for(i=0;i<v.size();i++)
    {
        v[i]=toupper(v[i]);
    }
    cout<<"\nmodified content:"<<endl;
    
     for(i=0;i<v.size();i++)
    {
        cout<<v[i]<<" ";
    }
    cout<<endl;
    return 0;
}

