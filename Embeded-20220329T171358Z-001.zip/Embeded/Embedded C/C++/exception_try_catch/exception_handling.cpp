class Test
{
    int x;
    public:
    void read()
    {
        cout<<"enter number=";
        cin>>x;
    }
    class Even();
    class Odd();
    void check()
    {
        if(x%2==0)
        {
            throw Even();
        }
        else
        {
            throw Odd();
        }
    }
}

int main()
{
    
}
