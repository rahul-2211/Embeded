#include<iostream>
using namespace std;
class Test
{
    int x;
    public:
    void read()
    {
        cout<<"enter number=";
        cin>>x;
    }
    class Even{};
    class Odd{};
    void check()
    {
        if(x%2==0)
        {
            throw Even();//abstract class for excepiton
        }
        else
        {
            throw Odd();
        }
    }
};

int main()
{
    Test t;
    t.read();
    try
    {
        t.check();
    }
    catch(Test::Even)//exception handler block
    {
        cout<<"num is even";
    }
    catch(Test::Odd)
    {
        cout<<"num is Odd";
    }
    return 0;
}
