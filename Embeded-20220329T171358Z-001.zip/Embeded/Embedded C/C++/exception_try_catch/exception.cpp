
#include <iostream>

using namespace std;

int main()
{
    int num,ans;
     num=10;
     ans=num/0;
     cout<<"Ans  "<<ans;

    return 0;
}
