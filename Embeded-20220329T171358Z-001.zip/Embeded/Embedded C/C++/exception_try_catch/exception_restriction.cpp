// example of restricted exception1
#include <iostream>
using namespace std;
void Demo() throw(int,double,char)
{
    int a=2;
    if(a==1)
    {
        throw a;
    }
    else if(a==2)
    {
        throw 'A';
    }
    else if(a==3)
    {
        throw 4.5;
    }
    
};


int main() {
    
    try
    {
        Demo();
    }
    catch(char n)
    {
        cout<<"\n Exception caught"<<endl;
    }
    cout<<"end of program";
    return 0;
}
