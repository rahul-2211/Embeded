/*
//starndard exception
#include <iostream>
#include <exception>
using namespace std;
int main() {

try
{
    int *myarray=new int[100];
}
catch(exception &e)
{
    cout<<"std exception"<<e.what()<<endl;
}
    return 0;
}*/

//starndard exception
//starndard exception
#include <iostream>
#include <exception>
using namespace std;
int main() {

try
{
    int *myarray=new int[100];

for(int i=0;i<120;i++)
{
    myarray[i]=i;
}
for(int i=0;i<120;i++)
{
    cout<<myarray[i]<<endl;
}
    // myarray="fdfhbnjkllk";
    // cout<<myarray;
}
catch(exception &e)
{
    cout<<"std exception"<<e.what()<<endl;
    
}
    return 0;
}
