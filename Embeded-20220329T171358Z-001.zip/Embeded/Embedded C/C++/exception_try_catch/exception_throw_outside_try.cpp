//Exception from outside the 'try' block
#include <iostream>
using namespace std;

void Xtest(int test)//function creation
{
    cout<<"inside the Xtest ,test is:"<<test<<endl;
    if(test)
        throw test;//throw from fun Xtest
}
//main body
int main() {
    
    cout<<"start\n";
    try
    {
        cout<<"inside the try block"<<endl;
        Xtest(0);
        Xtest(1);
        Xtest(2);
    }
    catch(int i)
    {
        cout<<"Caught an exception --value is:"<<i<<endl;
        
    }
    cout<<"End"<<endl;
    return 0;
}
