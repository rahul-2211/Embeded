#include<iostream>
using namespace std;
template<class X>
/*void swap(X &a,X &b){
    X temp;
    temp=a;
    a=b;
    b=temp;
    cout<<"inside the template swap";
}*/
void swap(X *a,X *b){
    X temp;
    temp=*a;
    *a=*b;
    *b=temp;
    cout<<"inside the template swap";
}
/*void swap(int &a,int &b)
{
    int temp;
    temp=a;
    a=b;
    b=temp;
    cout<<"inside int speciallization"<<endl;
    
}*/

int main()
{
    int i=10,j=20;
    double x=10.1,y=23.3;
    char a='x',b='z';
    cout<<"original i,j: "<<i<<' '<<j<<'\n';
    cout<<"original x,y: "<<x<<' '<<y<<'\n';
    cout<<"original a,b: "<<a<<' '<<b<<'\n';
    
    swap(&i,&j);
   swap(&x,&y);
    swap(&a,&b);
    
    cout<<"swapped i,j: "<<i<<' '<<j<<'\n';
    cout<<"swapped x,y: "<<x<<' '<<y<<'\n';
    cout<<"swapped a,b: "<<a<<' '<<b<<'\n';
    
    return 0;
}
