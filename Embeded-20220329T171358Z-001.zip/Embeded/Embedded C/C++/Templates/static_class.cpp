#include<iostream>

using namespace std;

	template<typename T>
class Demo
{
public:


//	 static int i=10;
	
	void fun(const T &x)
	{
	    //static int i=10;
	    i=10;
	    cout<< ++i <<endl;
	    return ;
	}
};

int main()
{
    Demo<int> d1;
    d1.fun(1);
    // fun<int>(1);
    // fun<int>(2);
  // d1.fun<double>(10.1);
    return 0;
}
