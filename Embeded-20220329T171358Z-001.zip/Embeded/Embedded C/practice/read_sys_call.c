#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
	int fd;
	//open("char *name,int flag,mode_t mode);
	fd=open("maxfd.c",O_CREAT|O_RDONLY,777);
	int res;
	printf("fd : %d\n",fd);
	char buf[300];
	if(fd<0)
		printf("file is not opened");
	//read(int fd,void *buf,size_t n bytes);
	read(fd,buf,300);
	printf("read data from buffer: %s",buf);
	close(fd);
	return 0;
	
}
