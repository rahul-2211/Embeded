#include<stdio.h>
void main()
{

printf("hello rahul::");
}
